﻿import multer from 'multer'
import { MAX_FILES, MAX_FILE_SIZE } from '../services/storage.js'

const storage = multer.memoryStorage()
const limits = { fileSize: MAX_FILE_SIZE }

// Accepting every mimetype (the previous behaviour) let an uploaded HTML/SVG
// file be stored and served back with a matching Content-Type, running as
// stored XSS in the victim's session (proved in testing). Listings, posts and
// stories are photo/video features, so only image/* and video/* are allowed;
// avatars are image-only. Chat attachments and payment receipts keep a wider
// allow-list since people legitimately share documents there.
// Reject (rather than silently drop) disallowed files so uploadHandler can
// surface a clear error instead of the file just vanishing from the request.
function mediaFilter(req, file, cb) {
  if (/^image\/|^video\//.test(file.mimetype)) return cb(null, true)
  cb(new Error('يسمح فقط بالصور والفيديو'))
}
function imageOnlyFilter(req, file, cb) {
  if (/^image\/(?!svg)/.test(file.mimetype)) return cb(null, true)
  cb(new Error('صورة غير صحيحة'))
}

export const listingUpload = multer({ storage, limits, fileFilter: mediaFilter }).array('images', MAX_FILES)
export const singleUpload = multer({ storage, limits, fileFilter: mediaFilter }).single('file')
export const avatarUpload = multer({ storage, limits, fileFilter: imageOnlyFilter }).single('file')
export const storyUpload = multer({ storage, limits, fileFilter: mediaFilter }).single('story')
export const receiptUpload = multer({ storage, limits }).single('receipt')

export function uploadHandler(middleware, route) {
  return (req, res, next) => {
    middleware(req, res, (err) => {
      if (err) {
        return res.status(400).json({ error: err.message || 'Upload error' })
      }
      Promise.resolve(route(req, res, next)).catch(next)
    })
  }
}

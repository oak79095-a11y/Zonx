﻿import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'
import { v4 } from 'uuid'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
export const UPLOAD_DIR = process.env.UPLOAD_DIR || (
  process.env.NODE_ENV === 'production'
    ? '/data/uploads'
    : path.join(__dirname, '..', 'uploads')
)

fs.mkdirSync(UPLOAD_DIR, { recursive: true })

export const MAX_FILES = 30
// Uploads are buffered fully in memory (multer.memoryStorage) before being
// written to disk, so two or three concurrent 1GB uploads could exhaust the
// server's RAM and crash the process (measured ~1.3GB RSS for two 300MB
// uploads in flight). 100MB comfortably covers photos/short video clips
// while keeping worst-case memory use bounded. Raise this only after moving
// uploads to disk-streaming (multer.diskStorage) instead of memoryStorage.
export const MAX_FILE_SIZE = 100 * 1024 * 1024 // 100MB

const EXTENSIONS = {
  'image/jpeg': '.jpg',
  'image/png': '.png',
  'image/webp': '.webp',
  'image/gif': '.gif',
  'video/mp4': '.mp4',
  'video/webm': '.webm',
  'video/quicktime': '.mov',
  'audio/mpeg': '.mp3',
  'audio/ogg': '.ogg',
  'audio/wav': '.wav',
  'audio/webm': '.weba',
  'application/pdf': '.pdf',
  'text/plain': '.txt',
  'application/zip': '.zip',
  'application/x-rar-compressed': '.rar',
  'application/vnd.rar': '.rar',
  'application/msword': '.doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
  'application/vnd.ms-excel': '.xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
  'application/vnd.ms-powerpoint': '.ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
  'application/vnd.android.package-archive': '.apk',
}

export function makeUploadDir(sub) {
  const dir = path.join(UPLOAD_DIR, sub)
  fs.mkdirSync(dir, { recursive: true })
  return dir
}

// Extensions safe to fall back to when the browser-supplied mimetype isn't in
// the EXTENSIONS map above. This used to accept ANY original extension
// (e.g. "evil.html"), which let an uploaded file be served back with
// Content-Type: text/html and run as stored XSS. Only known-safe media/doc
// extensions are allowed as a fallback now.
const SAFE_FALLBACK_EXT = new Set(Object.values(EXTENSIONS))

export function saveFile(file, sub = 'listings') {
  const dir = makeUploadDir(sub)
  const originalExt = path.extname(String(file.originalname || '')).toLowerCase()
  const ext = EXTENSIONS[file.mimetype] || (SAFE_FALLBACK_EXT.has(originalExt) ? originalExt : '.bin')
  const filename = `${v4()}${ext}`
  const dest = path.join(dir, filename)
  fs.writeFileSync(dest, file.buffer)
  return `/uploads/${sub}/${filename}`
}

export function deleteFile(relPath) {
  const abs = resolveUploadPath(relPath)
  if (abs && fs.existsSync(abs)) fs.unlinkSync(abs)
}

export function isStoredUploadPath(relPath, sub = null) {
  if (typeof relPath !== 'string' || !relPath.startsWith('/uploads/')) return false
  const abs = resolveUploadPath(relPath)
  if (!abs) return false
  if (sub && !relPath.startsWith(`/uploads/${sub}/`)) return false
  return true
}

function resolveUploadPath(relPath) {
  if (typeof relPath !== 'string' || !relPath.startsWith('/uploads/')) return null
  const relative = relPath.slice('/uploads/'.length)
  const root = path.resolve(UPLOAD_DIR)
  const abs = path.resolve(root, relative)
  if (abs !== root && !abs.startsWith(`${root}${path.sep}`)) return null
  return abs
}

export function uploadMiddleware(req, res, next) {
  next()
}
